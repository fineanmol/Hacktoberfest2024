from flask import Flask, render_template, redirect, url_for, request
from flask_sqlalchemy import SQLAlchemy

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = "sqlite:///database.sqlite3"
db = SQLAlchemy()
db.init_app(app)
app.app_context().push()



class Student(db.Model):
    __tablename__ = 'student'
    student_id = db.Column(db.Integer, primary_key = True, autoincrement = True)
    roll_number = db.Column(db.String, nullable = False, unique = True)
    first_name = db.Column(db.String, nullable = False)
    last_name = db.Column(db.String)
    
    
class Course(db.Model):
    __tablename__ = 'course'
    course_id = db.Column(db.Integer, primary_key = True, autoincrement = True)
    course_code = db.Column(db.String, nullable = False, unique = True)
    course_name =  db.Column(db.String, nullable = False)
    course_description = db.Column(db.String)
    
class Enrollments(db.Model):
    __tablename__ = 'enrollments'
    enrollment_id =  db.Column(db.Integer, primary_key = True, autoincrement = True)
    estudent_id = db.Column(db.Integer, db.ForeignKey('student.student_id'), nullable = False)
    ecourse_id = db.Column(db.Integer, db.ForeignKey('course.course_id'), nullable = False)


@app.route("/", methods = ['GET'])
def home():
    if request.method == 'GET':
        students = Student.query.all()
        return render_template("index.html", students = students)

@app.route("/student/create", methods = ['POST'])
def create_student():
    try:
        if request.method == 'POST':
            roll_no = request.form['roll']
            first_name = request.form['f_name']
            last_name = None
            if 'l_name' in request.form:
                last_name = request.form['l_name']
            courses_enrolled = request.form.getlist('courses')
        student = Student(roll_number = roll_no, first_name = first_name, last_name = last_name)
        db.session.add(student)
        db.session.commit()
        if 'course_1' in courses_enrolled:
            enrollment1 = Enrollments(estudent_id = student.student_id, ecourse_id = 1)
            db.session.add(enrollment1)
        if 'course_2' in courses_enrolled:
            enrollment2 = Enrollments(estudent_id = student.student_id, ecourse_id = 2)
            db.session.add(enrollment2)
        if 'course_3' in courses_enrolled:
            enrollment3 = Enrollments(estudent_id = student.student_id, ecourse_id = 3)
            db.session.add(enrollment3)
        if 'course_4' in courses_enrolled:
            enrollment4 = Enrollments(estudent_id = student.student_id, ecourse_id = 4)
            db.session.add(enrollment4)
        db.session.commit()
        return redirect(url_for("home"))
    except:
        return redirect(url_for("error"))
           
@app.route("/error",methods = ['GET'])
def error():
    return render_template('error_page.html')



@app.route("/student/<int:student_id>/delete",  methods = ['GET'])
def delete_student(student_id : int):
    student = Student.query.filter_by(student_id = student_id).first()
    temp_enrolls = Enrollments.query.filter_by(estudent_id = student.student_id).all()
    for t in temp_enrolls:
        db.session.delete(t)
    db.session.commit()
    db.session.delete(student)
    db.session.commit()
    return redirect(url_for("home"))

@app.route("/student/<int:student_id>/update",  methods = ['GET','POST'])
def update_student(student_id : int):
    if(request.method == 'GET'):
     
        student = Student.query.filter_by(student_id = student_id).first()
       
        return render_template('update_student_form.html', student = student)
    if(request.method == 'POST'):
        student = Student.query.filter_by(student_id = student_id).first()
        first_name = request.form['f_name']
        last_name = None
        if 'l_name' in request.form:
            last_name = request.form['l_name']
        courses_enrolled = request.form.getlist('courses')
        student.first_name = first_name
        student.last_name = last_name
        temp_enrolls = Enrollments.query.filter_by(estudent_id = student.student_id).all()
        for t in temp_enrolls:
            db.session.delete(t)
        db.session.commit()
        if 'course_1' in courses_enrolled:
            enrollment1 = Enrollments(estudent_id = student.student_id, ecourse_id = 1)
            db.session.add(enrollment1)
        if 'course_2' in courses_enrolled:
            enrollment2 = Enrollments(estudent_id = student.student_id, ecourse_id = 2)
            db.session.add(enrollment2)
        if 'course_3' in courses_enrolled:
            enrollment3 = Enrollments(estudent_id = student.student_id, ecourse_id = 3)
            db.session.add(enrollment3)
        if 'course_4' in courses_enrolled:
            enrollment4 = Enrollments(estudent_id = student.student_id, ecourse_id = 4)
            db.session.add(enrollment4)
        db.session.commit()
        return redirect(url_for("home"))


@app.route("/student/<int:student_id>", methods = ['GET'])
def view_student(student_id : int):
    if request.method == 'GET':
        student = Student.query.filter_by(roll_number = student_id).first()
        temp_enrolls = Enrollments.query.filter_by(estudent_id = student.student_id).all()
        course_ids = []
        for t in temp_enrolls:
            course_ids.append(t.ecourse_id)
        courses = db.session.query(Course).filter(Course.course_id.in_(course_ids)).all()
        return render_template("view_student_details.html", courses = courses, student = student)

@app.route("/add_student", methods = ['GET'])
def add_student():
    return render_template("create_student_form.html")



if __name__ == '__main__':
    app.run()